const { add, subtract } = require('./helpers')

console.log(add(1,2))
console.log(subtract(10, 5))