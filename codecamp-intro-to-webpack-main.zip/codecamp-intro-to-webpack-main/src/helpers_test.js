import { add, subtract } from "./helpers"

const addResults = add(20, 1)
const subtractResults = subtract(20, 1)

console.log('hello word')
console.log('addResults: ', addResults)
console.log('subtractResults: ', subtractResults)