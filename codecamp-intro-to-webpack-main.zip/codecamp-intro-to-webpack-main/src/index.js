import React from 'react';
import ReactDOM from 'react-dom';
 
ReactDOM.render(
  <h1>Hello React with Webpack from scratch</h1>,
  document.getElementById('root')
);