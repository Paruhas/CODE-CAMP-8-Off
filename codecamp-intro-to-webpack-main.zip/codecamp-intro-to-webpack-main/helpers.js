const subtract = function(a, b) {
  return a - b
}

const add = function(a, b) {
  return a + b
}

exports.add = add
exports.subtract = subtract